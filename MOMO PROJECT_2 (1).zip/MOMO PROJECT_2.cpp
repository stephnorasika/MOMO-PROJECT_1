#include<iostream>
using namespace std;

int main() {
	
	// Set default values
	string pin = "0000", new_pin, number;
	float balance = 1000;
	int attempts = 0, choice;
	bool authenticated = false;
	
	// Authenticate user
	string input_pin;
ecode:
	cout << "Enter your input_pin:\n";
	cin >> input_pin;
	
	if (input_pin == "*170#") {
		// Correct pin entered, reset attempt counter
		authenticated = true;
		attempts = 0;
	}
	else {
		// Incorrect pin entered, increment attempts counter
		attempts++;
		
		if (attempts >= 3) {
			// Too many attempts, exit program
			cout << "Too many attempts. Exiting program.\n";
			return 0;
		}
		
		cout << "Incorrect pin. Try again.\n";
		goto ecode;
	}
	
	// Loop until user exits
	while (authenticated) {
		// Authenticated, display menu
		cout << "1. Check balance\n";
		cout << "2. Send money\n";
		cout << "3. Change/reset pin\n";
		cout << "4. Exit\n";
		cout << "Enter your choice:\n";
		cin >> choice;
		
		// Handle user choice
		switch (choice) {
			case 1:
				// Check balance
				cout << "Enter momo pin to check balance: ";
				cin >> new_pin;
				
				if (new_pin == pin) {
					cout << "Your balance is " << balance << endl;
				}
				else {
					cout << "Wrong pin\a";
					return 0;
				}
				
				break;
				
			case 2:
				// Send money
				int amount;
				cout << "Enter number to send to: ";
				cin >> number;
				cout << "Enter amount to send: ";
				cin >> amount;
				cout << "Enter momo pin to send: ";
				cin >> new_pin;
				
				if (new_pin == pin) {
					if (amount > balance) {
						cout << "Insufficient amount.\n";
						return 0;
					}
					else {
						balance = balance - amount;
						cout << amount << " sent to " << number << endl;
						cout << "Balance is " << balance << endl;
						return 0;
					}
				}
				else {
					cout << "Wrong pin\a";
					return 0;
				}
				
				break;
				
			case 3:
				// Change pin
				cout << "Enter momo pin to change pin: ";
				cin >> new_pin;
				
				if (new_pin == pin) {
					cout << "Enter new pin: ";
					cin >> new_pin;
					cout << "Confirm new pin: ";
					cin >> pin;
					
					cout << "New pin is " << pin << endl;
				}
				else {
					cout << "Wrong pin\a";
					return 


